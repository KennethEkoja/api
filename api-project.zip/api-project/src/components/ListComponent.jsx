// src/components/ListComponent.jsx
import React from "react";
import PropTypes from "prop-types";
import "../App.css"; // Import shared styles

const ListComponent = ({ items, renderItem }) => {
  if (!items.length) {
    return <p>No data available.</p>;
  }

  return (
    <ul className="list">
      {items.map((item, index) => (
        <li key={index} className="item">
          {renderItem(item)}
        </li>
      ))}
    </ul>
  );
};

ListComponent.propTypes = {
  items: PropTypes.array.isRequired,
  renderItem: PropTypes.func.isRequired,
};

export default ListComponent;
