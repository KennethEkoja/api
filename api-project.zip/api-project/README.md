
# 📋 User Directory – React App

This is a simple React application that fetches and displays a list of users from an external API (`https://jsonplaceholder.typicode.com/users`). The app demonstrates basic use of React hooks (`useState`, `useEffect`), component reuse, conditional rendering, and error handling.

## 🚀 Features

- Fetch and display user data from a public API.
- Shows loading and error states.
- Reusable list component (`ListComponent`).
- Clean, modern UI using simple CSS.

## 🛠️ Technologies Used

- [React](https://reactjs.org/)
- JavaScript (ES6+)
- HTML5 & CSS3 (custom styling)
- Fetch API (for async data fetching)

---

## 📦 Installation

### 1. Clone the repository

```bash
git clone https://github.com/your-username/user-directory-app.git
cd user-directory-app
```

### 2. Install dependencies

```bash
npm install
```

### 3. Run the app locally

```bash
npm run dev
```

Visit: `http://localhost:5173` (if using Vite) or check terminal output for the correct port.

---

## 📂 Project Structure

```
src/
│
├── components/
│   └── ListComponent.jsx   # Reusable list renderer
│
├── App.jsx                 # Main component
├── App.css                 # App styling
└── main.jsx                # Entry point
```

---

## 📁 ListComponent Example Usage

The `ListComponent` is a flexible reusable component that accepts two props:

- `items`: An array of data.
- `renderItem`: A function to render each item.

Example usage:
```jsx
<ListComponent
  items={data}
  renderItem={(user) => (
    <div>
      <h2>{user.name}</h2>
      <p>Email: {user.email}</p>
      <p>Company: {user.company.name}</p>
    </div>
  )}
/>
```

---

## 📡 API Used

- **Endpoint:** `https://jsonplaceholder.typicode.com/users`
- **Returns:** Array of mock user data in JSON format.

---

## 🧪 Testing

Currently, no test setup is included. To add testing, you could integrate:

- [Jest](https://jestjs.io/)
- [React Testing Library](https://testing-library.com/docs/react-testing-library/intro/)

---

## ✅ Future Improvements

- Add search/filter functionality.
- Add pagination or infinite scroll.
- Improve UI with a design framework (e.g., Tailwind CSS or Material UI).
- Add unit and integration tests.

---

## 📝 License

This project is licensed under the MIT License.

---

## 🙋‍♀️ Author

Built by [Your Name](https://github.com/your-username)

---

## 🌐 Connect

- GitHub: [@your-username](https://github.com/your-username)
- LinkedIn: [Your LinkedIn](https://linkedin.com/in/your-profile)
